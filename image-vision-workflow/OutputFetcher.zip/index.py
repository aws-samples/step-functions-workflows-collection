import json
import json
import boto3
import os
# Initialize the DynamoDB client
dynamodb = boto3.client('dynamodb')
          
def lambda_handler(event, context):
  # Extract the value of the 'Key' header from the event
  path = event['path']
  parts = path.split('/')
  bucket = parts[1]
  key = parts[2]
  print(bucket)
  print(key)
  ImageKey = key
  # Define the DynamoDB table name
  dynamodb_table = os.environ['DYNAMODB_TABLE_NAME']
  print(ImageKey)
  try:
      # Query the DynamoDB table based on the key

      response = dynamodb.get_item(
          TableName=dynamodb_table,
          Key={
              'ImageKey': {'S': ImageKey}
          }
      )
      # Check if the item was found
      if 'Item' in response:
          # Extract the data from DynamoDB
          item = response['Item']
          data = item['BedrockOutput']['S']
          # Return the data as a JSON response
          return {
              'statusCode': 200,
              'body': data
          }
      else:
          # Return a 404 Not Found response if the item was not found
          return {
              'statusCode': 404,
              'body': json.dumps({
                  'message': 'Item not found'
              })
          }
  except Exception as e:
      # Return an error response if there was an issue with the DynamoDB query
      return {
          'statusCode': 500,
          'body': json.dumps({
              'message': 'Internal Server Error',
              'error': str(e)
          })
      }